Shader "Svinki/Pig Skin"
{
    Properties
    {
        [MainColor] _BaseColor("Skin", Color) = (.81,.365,.32,1)
        _PatternColor("Markings", Color) = (.085,.037,.024,1)
        _Pattern("Pattern", Float) = 0
        _Tattoo("Tattoo", Float) = 0
        _TattooPlacement("Tattoo placement", Float) = 0
        _HairInk("Integrated hair outline", Float) = 0
        _Smoothness("Smoothness", Range(0,1)) = .25
    }
    SubShader
    {
        Tags { "RenderPipeline"="UniversalPipeline" "RenderType"="Opaque" "Queue"="Geometry" }
        HLSLINCLUDE
        #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
        CBUFFER_START(UnityPerMaterial)
            half4 _BaseColor;
            half4 _PatternColor;
            half _Pattern;
            half _Tattoo;
            half _TattooPlacement;
            half _HairInk;
            half _Smoothness;
        CBUFFER_END
        struct Attributes
        {
            float4 positionOS : POSITION;
            float3 normalOS : NORMAL;
            // Bind-pose coordinates survive skinning, so markings never slide on an animated pig.
            float3 restPosition : TEXCOORD3;
            half4 color : COLOR;
            UNITY_VERTEX_INPUT_INSTANCE_ID
        };
        struct Varyings
        {
            float4 positionCS : SV_POSITION;
            float3 positionWS : TEXCOORD0;
            half3 normalWS : TEXCOORD1;
            float3 restPosition : TEXCOORD2;
            half fog : TEXCOORD3;
            half hairInk : TEXCOORD4;
            UNITY_VERTEX_OUTPUT_STEREO
        };
        Varyings PigVertex(Attributes input)
        {
            Varyings output = (Varyings)0;
            UNITY_SETUP_INSTANCE_ID(input);
            UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);
            VertexPositionInputs position = GetVertexPositionInputs(input.positionOS.xyz);
            output.positionCS = position.positionCS;
            output.positionWS = position.positionWS;
            output.normalWS = TransformObjectToWorldNormal(input.normalOS);
            output.restPosition = input.restPosition;
            output.hairInk = input.color.r;
            output.fog = ComputeFogFactor(position.positionCS.z);
            return output;
        }
        float2 CoatUV(float3 p)
        {
            // Project by the bind-pose surface normal, including limbs and the top of the head.
            // 3D spheres used to intersect only occasional patches of the skin.
            float3 n=abs(cross(ddx(p),ddy(p)));
            return n.z>=max(n.x,n.y)?p.xy:n.x>=n.y?p.zy:p.xz;
        }
        float StarDistance(float2 q)
        {
            float sector=1.256637;
            float angle=abs(frac(atan2(q.x,q.y)/sector+.5)-.5)*sector;
            float2 folded=float2(sin(angle),cos(angle))*length(q);
            float2 normal=normalize(float2(.9-.36*cos(.6283185),.36*sin(.6283185)));
            return dot(folded,normal)-.9*normal.y;
        }
        float3 CoatRandom(float2 cell)
        {
            float3 h=frac(float3(cell.x,cell.y,cell.x)*float3(.1031,.1030,.0973));
            h+=dot(h,h.yxz+33.33);
            return frac((h.xxy+h.yzz)*h.zyx);
        }
        half ScatteredMarkings(float2 q)
        {
            float2 origin=floor(q);
            float coverage=0;
            // Search neighbouring centres so marks can cross cell boundaries without clipping.
            // Vacancies, large jitter, scale and rotation changes remove visible rows.
            [unroll] for(int y=-1;y<=1;y++)
            [unroll] for(int x=-1;x<=1;x++)
            {
                float2 cell=origin+float2(x,y);
                float3 random=CoatRandom(cell);
                float3 variation=CoatRandom(cell+float2(41.73,19.29));
                float2 local=q-cell-(.08+.84*random.xy);
                float angle=variation.x*6.2831853;
                local=mul(float2x2(cos(angle),-sin(angle),sin(angle),cos(angle)),local);
                float size=lerp(.18,.35,random.z);
                float d;
                float mark;
                if(_Pattern<1.5)
                {
                    d=length(local*float2(1,lerp(.85,1.18,variation.y)))-size;
                    float edge=max(fwidth(d),.008);
                    mark=1-smoothstep(-edge,edge,d);
                }
                else if(_Pattern<3.5)
                {
                    float2 shape=local*float2(1,lerp(.8,1.2,variation.y));
                    float a=atan2(shape.y,shape.x);
                    float radius=length(shape);
                    float ring=abs(radius-size*(1+.15*sin(a*3+variation.z*6)))-size*.19;
                    float edge=max(fwidth(ring),.008);
                    float broken=smoothstep(-.55,-.15,sin(a*2+variation.z*8));
                    float center=(1-smoothstep(size*.16,size*.32,radius))*step(.73,variation.y);
                    mark=max((1-smoothstep(-edge,edge,ring))*broken,center);
                }
                else
                {
                    d=StarDistance(local/(size*1.65));
                    float edge=max(fwidth(d),.018);
                    mark=1-smoothstep(-edge,edge,d);
                }
                coverage=max(coverage,mark*step(.22,variation.z));
            }
            return coverage;
        }
        half Markings(float3 p)
        {
            if (_Pattern < .5) return 0;
            float2 q=CoatUV(p)*8;
            if (_Pattern < 1.5) return ScatteredMarkings(q);
            if (_Pattern < 2.5)
            {
                float stripe=sin(p.y*32+p.x*9+p.z*5);float edge=max(fwidth(stripe),.04);
                return smoothstep(.15-edge,.15+edge,stripe);
            }
            if (_Pattern < 3.5) return ScatteredMarkings(q);
            if (_Pattern < 4.5)
            {
                return fmod(abs(floor(q.x)+floor(q.y)),2);
            }
            return ScatteredMarkings(q);
        }
        float TriangleDistance(float2 q, float2 a, float2 b, float2 c)
        {
            float2 ab=b-a, bc=c-b, ca=a-c;
            float2 pa=q-a, pb=q-b, pc=q-c;
            float2 ea=pa-ab*saturate(dot(pa,ab)/dot(ab,ab));
            float2 eb=pb-bc*saturate(dot(pb,bc)/dot(bc,bc));
            float2 ec=pc-ca*saturate(dot(pc,ca)/dot(ca,ca));
            float s1=ab.x*pa.y-ab.y*pa.x, s2=bc.x*pb.y-bc.y*pb.x, s3=ca.x*pc.y-ca.y*pc.x;
            float inside=(min(s1,min(s2,s3))>=0 || max(s1,max(s2,s3))<=0) ? -1 : 1;
            return sqrt(min(dot(ea,ea),min(dot(eb,eb),dot(ec,ec))))*inside;
        }
        half Tattoo(float3 p)
        {
            if (_Tattoo < .5) return 0;
            float2 q;float mask;
            if(_TattooPlacement<.5)
            {
                q=float2(p.x-.425,p.y-.87)/.095;
                mask=smoothstep(.34,.38,p.x)*smoothstep(.015,.065,p.z);
            }
            else if(_TattooPlacement<1.5)
            {
                q=float2(p.x+.18,p.y-1.08)/.13;
                mask=(1-smoothstep(-.14,-.05,p.z))*(1-smoothstep(-.02,.02,p.x));
            }
            else if(_TattooPlacement<2.5)
            {
                q=float2(p.x-.177,p.y-.29)/.085;
                mask=(1-smoothstep(.43,.49,p.y))*smoothstep(.01,.055,p.z);
            }
            else
            {
                q=float2(p.x,p.y-.96)/.20;
                mask=1-smoothstep(-.14,-.05,p.z);
            }
            float d=1;
            if (_Tattoo < 1.5)
            {
                float lobes=min(length(q-float2(-.32,.26)),length(q-float2(.32,.26)))-.44;
                float tip=TriangleDistance(q,float2(-.72,.25),float2(.72,.25),float2(0,-.78));
                d=min(lobes,tip);
            }
            else if (_Tattoo < 2.5)
            {
                d=StarDistance(q);
            }
            else if (_Tattoo < 3.5)
            {
                float upper=TriangleDistance(q,float2(-.15,.95),float2(.45,.95),float2(-.33,-.24));
                float lower=TriangleDistance(q,float2(-.33,-.12),float2(.33,.14),float2(-.42,-.95));
                d=min(upper,lower);
            }
            else
            {
                float bands=abs(sin(q.y*10));
                return mask*(1-smoothstep(.65,.8,abs(q.x)))*(1-smoothstep(.65,.8,abs(q.y)))*smoothstep(.42,.62,bands);
            }
            float edge=max(fwidth(d),.012);
            return (1-smoothstep(-edge,edge,d))*mask;
        }
        half4 PigFragment(Varyings input) : SV_Target
        {
            UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(input);
            InputData lighting = (InputData)0;
            lighting.positionWS = input.positionWS;
            lighting.positionCS = input.positionCS;
            lighting.normalWS = NormalizeNormalPerPixel(input.normalWS);
            lighting.viewDirectionWS = GetWorldSpaceNormalizeViewDir(input.positionWS);
            lighting.shadowCoord = TransformWorldToShadowCoord(input.positionWS);
            lighting.bakedGI = SampleSH(lighting.normalWS);
            lighting.normalizedScreenSpaceUV = GetNormalizedScreenSpaceUV(input.positionCS);
            lighting.shadowMask = half4(1,1,1,1);
            lighting.vertexLighting = VertexLighting(input.positionWS, lighting.normalWS);
            SurfaceData surface = (SurfaceData)0;
            surface.albedo = lerp(_BaseColor.rgb, _PatternColor.rgb, Markings(input.restPosition));
            surface.albedo = lerp(surface.albedo, half3(.015,.024,.032), Tattoo(input.restPosition));
            surface.albedo = lerp(surface.albedo, half3(.012,.010,.009), _HairInk*smoothstep(.15,.85,input.hairInk));
            surface.alpha = 1;
            surface.smoothness = _Smoothness;
            surface.normalTS = half3(0,0,1);
            surface.occlusion = 1;
            half4 color = UniversalFragmentPBR(lighting, surface);
            color.rgb = MixFog(color.rgb, input.fog);
            return color;
        }
        half4 DepthFragment(Varyings input) : SV_Target { return 0; }
        half4 NormalsFragment(Varyings input) : SV_Target { return half4(NormalizeNormalPerPixel(input.normalWS), 0); }
        float3 _LightDirection;
        float3 _LightPosition;
        Varyings ShadowVertex(Attributes input)
        {
            Varyings output = PigVertex(input);
            #if defined(_CASTING_PUNCTUAL_LIGHT_SHADOW)
                float3 direction = normalize(_LightPosition - output.positionWS);
            #else
                float3 direction = _LightDirection;
            #endif
            output.positionCS = ApplyShadowClamping(TransformWorldToHClip(
                ApplyShadowBias(output.positionWS, output.normalWS, direction)));
            return output;
        }
        ENDHLSL
        Pass
        {
            Name "ForwardLit"
            Tags { "LightMode"="UniversalForwardOnly" }
            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex PigVertex
            #pragma fragment PigFragment
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
            #pragma multi_compile _ _ADDITIONAL_LIGHTS_VERTEX _ADDITIONAL_LIGHTS
            #pragma multi_compile_fragment _ _ADDITIONAL_LIGHT_SHADOWS
            #pragma multi_compile_fragment _ _SHADOWS_SOFT _SHADOWS_SOFT_LOW _SHADOWS_SOFT_MEDIUM _SHADOWS_SOFT_HIGH
            #pragma multi_compile_fragment _ _SCREEN_SPACE_OCCLUSION
            #pragma multi_compile_fragment _ _LIGHT_COOKIES
            #pragma multi_compile _ _CLUSTER_LIGHT_LOOP
            #pragma multi_compile_instancing
            #include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Fog.hlsl"
            ENDHLSL
        }
        Pass
        {
            Name "ShadowCaster"
            Tags { "LightMode"="ShadowCaster" }
            ColorMask 0
            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex ShadowVertex
            #pragma fragment DepthFragment
            #pragma multi_compile_vertex _ _CASTING_PUNCTUAL_LIGHT_SHADOW
            #pragma multi_compile_instancing
            ENDHLSL
        }
        Pass
        {
            Name "DepthOnly"
            Tags { "LightMode"="DepthOnly" }
            ColorMask R
            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex PigVertex
            #pragma fragment DepthFragment
            #pragma multi_compile_instancing
            ENDHLSL
        }
        Pass
        {
            Name "DepthNormals"
            Tags { "LightMode"="DepthNormalsOnly" }
            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex PigVertex
            #pragma fragment NormalsFragment
            #pragma multi_compile_instancing
            ENDHLSL
        }
    }
}
